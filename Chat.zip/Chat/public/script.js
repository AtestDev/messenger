const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const messagesContainer = document.getElementById('messages');

// نام کاربری ساده (در حالت واقعی باید از کاربر دریافت شود)
const username = `کاربر_${Math.floor(Math.random() * 1000)}`;

// دریافت پیام‌ها هر 2 ثانیه
function fetchMessages() {
    fetch('/api/messages')
        .then(response => response.json())
        .then(messages => {
            messagesContainer.innerHTML = '';
            messages.forEach(message => {
                const messageElement = document.createElement('div');
                messageElement.classList.add('message');
                messageElement.classList.add(message.sender === username ? 'sent' : 'received');
                messageElement.innerHTML = `
                    <strong>${message.sender}:</strong> ${message.text}
                    <div class="time">${new Date(message.timestamp).toLocaleTimeString()}</div>
                `;
                messagesContainer.appendChild(messageElement);
            });
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        })
        .catch(error => console.error('Error fetching messages:', error));
}

// ارسال پیام
function sendMessage() {
    const text = messageInput.value.trim();
    if (text) {
        fetch('/api/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sender: username,
                text: text,
                timestamp: new Date().toISOString()
            }),
        })
        .then(response => response.json())
        .then(() => {
            messageInput.value = '';
            fetchMessages();
        })
        .catch(error => console.error('Error sending message:', error));
    }
}

// رویدادها
sendButton.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// دریافت اولیه پیام‌ها و تنظیم interval برای دریافت مداوم
fetchMessages();
setInterval(fetchMessages, 2000);
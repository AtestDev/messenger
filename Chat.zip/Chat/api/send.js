// یک دیتابیس ساده در حافظه (در پروژه واقعی از دیتابیس استفاده کنید)
let messages = [];

export default async function handler(req, res) {
    if (req.method === 'POST') {
        const { sender, text, timestamp } = req.body;
        
        if (!sender || !text) {
            return res.status(400).json({ error: 'Sender and text are required' });
        }
        
        const newMessage = { sender, text, timestamp };
        messages.push(newMessage);
        
        // محدود کردن تعداد پیام‌ها برای جلوگیری از مصرف زیاد حافظه
        if (messages.length > 100) {
            messages = messages.slice(-100);
        }
        
        return res.status(200).json(newMessage);
    } else {
        return res.status(405).json({ error: 'Method not allowed' });
    }
}